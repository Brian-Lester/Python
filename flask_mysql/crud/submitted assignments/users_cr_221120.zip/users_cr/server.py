from flask import Flask, render_template,request,redirect
from users import User
app = Flask(__name__)

@app.route('/')
def home_page():
    return render_template('create.html')

@app.route('/create', methods=['post'])
def create():
    data = {
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"],
    }
    User.save(data)
    return redirect('/display')

@app.route('/display')
def display():
    test= User.get_all()
    return render_template('display.html', test=test)






if __name__ == "__main__":
    app.run(debug=True)