from flask_app import app
from flask import render_template,redirect,request,session,flash
mydb ="exam2"
from flask_app.models import car, purchased,user

@app.route('/car/form')
def show_form():
    if 'user_id' in session:
        return render_template('newCar.html')
    return redirect('/')

@app.route('/create/car', methods=['post'])
def create_car():
    if 'user_id' not in session:
        return redirect('/')
    if car.Car.validate_car(request.form) == True:
        data ={
            'price': request.form['price'],
            'model':request.form['model'],
            'make':request.form['make'],
            'year':request.form['year'],
            'description': request.form['description'],
            'user_id': session['user_id']
        }
        car.Car.save(data)
        return redirect('/dashboard')
    return redirect ('/car/form')

@app.route('/show/car/<int:id>')
def show_car(id):
    if 'user_id' not in session:
        return redirect('/')
    onecar= car.Car.get_by_id({'id':id})
    return render_template('showCar.html', c= onecar)

@app.route('/update/car/<int:id>')
def update_car(id):
    if 'user_id' not in session:
        return redirect('/')
    onecar= car.Car.get_by_id({'id':id})
    return render_template('editCar.html', c= onecar )


@app.route('/update/car/save/<int:id>', methods=['post'])
def update_car_save(id):
    if 'user_id' not in session:
        return redirect('/')
    if car.Car.validate_car(request.form) == True:
        data ={
            "id":id,
            'price': request.form['price'],
            'model':request.form['model'],
            'make':request.form['make'],
            'year':request.form['year'],
            'description': request.form['description']
        }
        car.Car.save_update(data)
        return redirect('/dashboard')
    return redirect (f'/update/car/{id}')

@app.route('/delete/car/<int:id>')
def delete_car(id):
    if 'user_id' not in session:
        return redirect('/')
    car.Car.delete({'id':id})
    return redirect('/dashboard')

@app.route('/create/relationship/<int:id>')
def create_relationship(id):
    if 'user_id' not in session:
        return redirect('/')
    data = {
        'car_id': id,
        'user_id':session['user_id']
    }
    purchased.Purchased.save(data)
    return redirect('/dashboard')


@app.route('/mycars/<int:id>')
def show_cars(id):
    if 'user_id' not in session:
        return redirect('/')
    current_user =user.User.get_by_id({'id':session['user_id']})
    cars= user.User.get_by_user_id({'id': id})
    return render_template('mycars.html', cars=cars,user=current_user)





