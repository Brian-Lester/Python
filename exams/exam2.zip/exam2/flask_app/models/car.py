from flask_app.config.mysqlconnection import connectToMySQL
from flask import  flash, request
mydb ="exam2"

class Car:
    def __init__( self , data ):
        self.id = data['id']
        self.price = data['price']
        self.model = data['model']
        self.make = data['make']
        self.year =data['year']
        self.description =data['description']
        self.user_id =data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.Creator = None


    @classmethod
    def save(cls, data ):
        query = "INSERT INTO cars ( price , model , make, year, description, user_id) VALUES ( %(price)s , %(model)s ,%(make)s,%(year)s,%(description)s ,%(user_id)s  );"

        return connectToMySQL(mydb).query_db( query, data )


    @classmethod
    def delete(cls, data):
        query = 'DELETE FROM cars WHERE id = %(id)s'

        results = connectToMySQL(mydb).query_db( query, data )
        return results

    @classmethod
    def get_by_id(cls,data):
        query = "SELECT cars.*, users.first_name, users.last_name FROM cars JOIN users ON cars.user_id = users.id WHERE cars.id = %(id)s;"

        results = connectToMySQL(mydb).query_db(query,data)
        car =cls(results[0])
        car.Creator= results[0]['first_name'] + " " + results[0]['last_name']

        return car


    @classmethod
    def save_update(cls,data):
        query = "UPDATE cars SET price =%(price)s , model=%(model)s, make=%(make)s, year=%(year)s, description=%(description)s, updated_at=NOW() where id = %(id)s;"
        results= connectToMySQL(mydb).query_db( query, data )


    @staticmethod
    def validate_car(user):
        is_valid = True
        if len(user['price']) <1:
            flash("Price Must be greater than 0", 'error')
            is_valid = False
        elif int(user['price']) < 0:
            flash("Price Must be greater than 0", 'error')
            is_valid = False
        if len(user['make']) < 1:
            flash("Please enter the make of your car", 'error')
            is_valid = False
        if len(user['model']) < 1:
            flash('Please enter the model of your car', 'error')
            is_valid = False
        if int(user['year']) <= 0:
            flash("Please enter the model year of your car", 'error')
            is_valid = False
        if len(user['description']) < 1:
            flash('Please enter a brief description', 'error')
            is_valid = False
        return is_valid

    @classmethod
    def get_all(cls):
        query = "SELECT cars.*, users.first_name, users.last_name FROM cars JOIN users ON cars.user_id = users.id ;"

        results = connectToMySQL(mydb).query_db(query)
        print(results)

        cars =[]

        for car in results:
            this_car =cls(car)
            this_car.Creator =car['first_name'] +" " + car['last_name']
            cars.append( this_car)
        return cars





