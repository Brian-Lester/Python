from flask_app.config.mysqlconnection import connectToMySQL
from flask import  flash, request
mydb ="exam2"

class Purchased:
    def __init__( self , data ):
        self.car_id = data['car_id']
        self.user_id = data['user_id']





    @classmethod
    def save(cls, data ):
        query = "INSERT INTO cars_purchased ( car_id, user_id) VALUES ( %(car_id)s  ,%(user_id)s  );"

        return connectToMySQL(mydb).query_db( query, data )

    @classmethod
    def get_all(cls):
        query = "SELECT car_id FROM cars_purchased;"

        results = connectToMySQL(mydb).query_db(query)

        cars = []
        for car in results:
            this_car=car['car_id'] 
            cars.append(this_car)
        return cars

