from django.apps import AppConfig


class ShowTimeConfig(AppConfig):
    name = 'show_time'
